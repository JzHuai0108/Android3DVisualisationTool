Android 3D Visualisation Tool
=============================

###Overview
Visualisation tool for 3D point cloud research project. This tool is based on android and opengl es, and developed on android studio v0.6.1.

###Requirements
This tool has been tested on Nexus 5 with Kitkat 4.4.3.

###Screen Shots
<img style="float: left" src="https://raw.githubusercontent.com/pan-long/Android3DVisualisationTool/master/img1.png" />
<img style="padding: 10px;" src="https://raw.githubusercontent.com/pan-long/Android3DVisualisationTool/master/img2.png" />
<img style="float: right" src="https://raw.githubusercontent.com/pan-long/Android3DVisualisationTool/master/img3.png" />
